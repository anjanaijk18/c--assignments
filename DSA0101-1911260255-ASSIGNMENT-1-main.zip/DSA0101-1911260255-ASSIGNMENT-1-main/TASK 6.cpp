#include <iomanip>
#include <iostream>
using namespace std;

enum class Zone {
    Inner,
    Middle,
    Outer
};

constexpr long long BASE_PAISE[] = {1000, 2000, 3000};
constexpr int PEAK_SURCHARGE_PERCENT = 20;
constexpr long long MIN_BALANCE_PAISE = 5000;

long long fare(Zone z, bool peak) {
    long long baseFare = 0;

    switch (z) {
        case Zone::Inner:
            baseFare = BASE_PAISE[0];
            break;

        case Zone::Middle:
            baseFare = BASE_PAISE[1];
            break;

        case Zone::Outer:
            baseFare = BASE_PAISE[2];
            break;

        default:
            return -1;
    }

    if (peak) {
        baseFare +=
            baseFare * PEAK_SURCHARGE_PERCENT / 100;
    }

    return baseFare;
}

bool canTravel(long long balance, long long f) {
    return f >= 0 &&
           balance >= f &&
           balance - f >= MIN_BALANCE_PAISE;
}

int main() {
    long long balance = 10000;

    struct Trip {
        Zone zone;
        bool peak;
    };

    Trip trips[] = {
        {Zone::Inner, false},
        {Zone::Outer, true},
        {Zone::Middle, false}
    };

    for (const Trip& t : trips) {
        long long f = fare(t.zone, t.peak);

        if (canTravel(balance, f)) {
            balance -= f;

            cout << "Fare Rs "
                 << f / 100 << '.'
                 << setw(2) << setfill('0')
                 << f % 100
                 << setfill(' ');
        } else {
            cout << "Denied (low balance)";
        }

        cout << " balance Rs "
             << balance / 100 << '\n';
    }

    return 0;
}
OUTPUT:
Fare Rs 10.00 balance Rs 90
Fare Rs 36.00 balance Rs 54
Denied (low balance) balance Rs 54
